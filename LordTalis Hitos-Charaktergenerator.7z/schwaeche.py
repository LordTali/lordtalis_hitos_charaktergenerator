from steuerelemente import *
from charakter import *
import random
from colorama import Fore


"""
In dieser Datei wird die Schwäche des Charakters bestimmt.
"""


def schwaeche():
    print("Außerdem braucht deion Charakter noch irgendeine Art von Schwäche, "
          "die ihm das Leben etwas schwerer macht.\n")
    warte()
    print(f"Das kann zum Beispiel etwas wie {Fore.YELLOW}Trockener Alkoholiker{Fore.RESET} "
          f"oder {Fore.YELLOW}Asthma{Fore.RESET} oder {Fore.YELLOW}Hat nur einen Arm{Fore.RESET} sein.\n")
    print("Willst du diese selbst erstellen oder zufällig erstellen lassen?\n")
    while True:
        frage = input(f"Gib {Fore.YELLOW}1{Fore.RESET} ein, wenn du für deinen Charakter selbst eine Schwäche "
                      f"ausdenken willst, oder etwas Anderes, wenn du díese zufällig bestimmen willst.\n > ")
        if frage == "1":
            auswahl = input("Gib nun die Schwäche deines Charakters ein: \n > ")
            hitos_pc.schwaeche = auswahl
            warte()
            return True
        else:
            return False


def schwaeche_generiert():
    print("Alles klar! Dann erstellen wir jetzt eine zufällige Schwäche für deinen Charakter.\n")
    warte()
    schwaechen = ["Trockener Alkoholiker", "Ehemaliger Drogenabhängiger", "Zitterhände", "Stotterer", "Reizbar",
                  "Leidet an posttraumatischer Belastungsstörung.", "Hat Schuldgefühle.", "Überheblich", "Gierig"
                  "Unvorsichtig", "Dickkopf", "Leidet an Verfolgungswahn", "Stark abergläubisch", "Ungeduldig",
                  "Sozial unangepasst", "Geizkragen", "Leidet an Psychose.", "Hört Stimmen.", "Humpelt.", "Egoistisch"
                  "Klaustrophobie", "Workaholic", "Naiv", "Starrsinnig", "Überlegenheitsgefühle", "Eifersüchtig",
                  "Minderwertigkeitsgefühle", "Leidet an Depression.", "Nicht stressresistent", "Feige",
                  "Leidet an Panikattacken/Angstzuständen", "Impulsiv", "Überfürsorglich", "Leidet an Putzzwang.",
                  "Eingefahren.", "Hypochonder", "Chronischer Schlafmangel durch Albträume", "Konfliktscheu",
                  "Angst vor Feuer",]
    hitos_pc.schwaeche = random.choice(schwaechen)
    print(f"Deine Schwäche ist: {Fore.YELLOW}hitos_pc.schwaeche{Fore.RESET}\n")
    warte()
    return

