from steuerelemente import *
from charakter import *
from colorama import Fore
import random

"""
Diese Datei enthält den Begrüßungstest, die Genre-Auswahl und die Rassen- bzw. Spezieswahl.
"""

def willkommen():
    print(f"Willkommen bei {Fore.YELLOW}LordTalis Hitos-Charaktergenerator{Fore.RESET}.\n")
    warte()
    print("Dies ist ein simples Programm, das Rollenspielern im Hitos-System dabei helfen soll, auf die Schnelle einen"
          "Charakter zu erstellen.\n")
    warte()
    print(f"Ein wichtiges Wort vorweg: Das Hitos-System wurde vom spanischen Verlag "
          f"{Fore.YELLOW}Nosolorol Ediciones{Fore.RESET} entwickelt.\n")
    warte()
    print("Entsprechend liegen die Rechte beim Verlag, das Hitos-System ist aber Open Content.\n")
    warte()
    print("Es kann unter der OGL-Lizenz verwendet werden. Die anderen Bestandteile von konkreten Spielen können nur "
          "mit Genehmigung des Verlages verwendet werden.\n")
    warte()
    print("Die Produktidentität wird unter der OGL-Lizenz erklärt.\n")
    warte()
    print("Dieser Charaktergenerator nutzt die unter der OGL-Lizenz gelisteten Regeln zur Erleichetrung "
          "der Charaktererstellung.\n")
    warte()
    print("Der Schöpfer dieses Programms erhebt keinen Anspruch auf geistiges Eigentum am Hitos-System "
          "oder den darunter entwickelten Spielen.\n")
    warte()
    print("Aber nachdem wir das Rechtliche geklärt haben: Legen wir los!\n")
    warte()
    return


def genre():
    genres = [f"(Lovecraftischer) Horror (am besten bekannt durch {Fore.YELLOW}Unaussprechliche Kulte{Fore.RESET})",
              "Science-Fiction", "Fantasy", "[Anderes Genre]"]
    dict_genre = {}
    print("Fangen wir simpel an!\n")
    warte()
    print("Das Hitos-System versteht sich als unabhängig vom Genre. "
          "Dennoch kann es in bestimmten Situationen eine Rolle Spielen.\n")
    warte()
    for index, element in enumerate(genres, 1):
        dict_genre[index] = element
        print(f"{index}: {element}\n")
        wartekurz()
    while True:
        try:
            frage = int(input("In welchem Genre spielt deine Gruppe? Bitte gib die Nummer der Option als "
                              "Antwort ein.\n > "))
            warte()
        except (ValueError, TypeError):
            hoppla()
            warte()
            continue
        else:
            if frage == 1:
                Spiel.genre["Horror"] = True
                return
            elif frage == 2:
                Spiel.genre["Sci-Fi"] = True
                return
            elif frage == 3:
                Spiel.genre["Fantasy"] = True
                return
            elif frage == 4:
                return
            else:
                hoppla()


def rasse():
    print("Spielt deine Gruppe nur Menschen, oder sind ander Rassen/Spezies erlaubt?\n")
    warte()
    frage = input(f"Gib bitte {Fore.YELLOW}1{Fore.RESET} ein, wenn auch Nichtmenschen erlaubt sind, "
                  f"oder etwas Anderes, wenn ihr nur Menschen spielt.\n > ")
    if frage == "1":
        Spiel.rassen = True
        return True
    else:
        return False


def wahl_rasse():
    if not Spiel.genre["Sci-Fi"]:
        liste_rassen = ["Eigene Rasse/Spezies", "Mensch", "Elf", "Zwerg", "Ork", "Halbelf", "Halbling", "Kängu",
                        "Minotaurus"]
    else:
        liste_rassen = ["Eigene Rasse/Spezies", "Mensch", "Elf", "Zwerg", "Ork", "Halbelf", "Halbling", "Kängu",
                        "Minotaurus", "Limakoid"]
    dict_rassen = {}
    print("Je nach Genre kann das Hitos-System eine breite Palette von Lebewesen abdecken.\n")
    warte()
    print("Dieser Charakter-Generator greift die bekanntesten Vertreter der Genre-Klassik auf.\n")
    warte()
    print("Plus noch die Optionen aus dem offiziellen Regelwerk für das System.\n")
    warte()
    print("Wenn deine Gruppe davon abweicht, sprich am besten mit deinem Spielleiter darüber.\n")
    warte()
    print("Die Wahl hat primär Auswirkungen auf die verfügbaren Attributs- und Fertigkeitspunkte.\n")
    warte()
    print("Bei einer unvorhergesehenen Abweichung bekommst du aber noch die Möglichkeit, sie anzupassen.\n")
    for index, element in enumerate(liste_rassen, 0):
        dict_rassen[index] = element
        print(f"{index}: {element}\n")
        wartekurz()
    print("Dabei geht dieses Programm davon aus, dass deine Gruppe die Optionen bereits besprochen hat.\n")
    warte()
    print()
    while True:
        try:
            frage = int(input(f"Gib jetzt die Zahl ein, die der Rasse/Spezies deines Charakters entspricht, "
                              f"oder {Fore.YELLOW}-1{Fore.RESET}, um eine zufällige Auswahl zu treffen.\n > "))
            warte()
        except (ValueError, TypeError, IndexError):
            hoppla()
            warte()
            continue
        else:
            if frage == -1:     # Die Rassenauswahl wird je nach Antwortnummer aus der Liste gegriffen und zugewiesen.
                hitos_pc.rasse = random.choice(liste_rassen[1:])    # Index 0 ist Eigenbräu.
            elif frage == 0:
                hitos_pc.rasse = "Eigenbräu"
            else:
                if 1 <= frage <= len(liste_rassen)-1:   # Wenn die Auswahl im Index der Rassenwahl ist, aber keine 0.
                    hitos_pc.rasse = liste_rassen[frage]
                else:
                    if Spiel.genre["Sci-Fi"]:
                        hitos_pc.rasse = "Limakoid"  # Der letzte Index für den Limakoiden reserviert.
                    else:
                        hitos_pc.rasse = "Minotaurus"  # Da Limakoiden für Sci-Fi reserviert sind.
            print(f"Verstanden! Deine Rasse/Spezies ist also {Fore.YELLOW}{hitos_pc.rasse}{Fore.RESET}.\n")
            warte()
            return
