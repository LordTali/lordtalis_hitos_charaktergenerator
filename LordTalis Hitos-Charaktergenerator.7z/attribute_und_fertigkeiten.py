from steuerelemente import *
from charakter import *
from colorama import Fore
import random

"""In dieser Datei werden die Attribute und Fertigkeiten des Charakters
    sowie deren jeweilige Konkretisierungen bestimmt.
"""


def attribute():
    print("Wenn du ein bisschen Erfahrung mit dem Hitos-System oder eine Idee für die vier Attribute deines Charakters "
          f"hast, dann gib jetzt {Fore.YELLOW}1{Fore.RESET} ein.\n")
    warte()
    print("Alternativ: Wenn du Hilfe brauchst und einen Archetyp verwenden willst, "
          f"gib jetzt irgendetwas Anderes als {Fore.YELLOW}1{Fore.RESET} ein.\n")
    warte()
    print("In diesem Fall werden die Attribute und Fertigkeiten je nach dem gewünschten Archetyp "
          "zufällig bestimmt.\n")
    warte()
    frage = input("Triff jetzt deine Auswahl.\n > ")
    return frage


def attribute_bestimmen():
    attribute = []
    print("Die Attribute beschreiben die körperliche und geistige Stärke deines Charakters.\n")
    warte()
    print(f"Das Hitos-System sieht vier Attribute vor: {Fore.YELLOW}Stärke, Reflexe, "
          f"Wille und Intellekt{Fore.RESET}.\n")
    warte()
    print(f"Darauf musst du jetzt {Fore.YELLOW}{Spiel.punkte["Attribute"]}{Fore.RESET} Punkte verteilen.\n")
    warte()
    print(f"Jedes Attribut muss zwischen {Fore.YELLOW}1{Fore.RESET} und "
          f"{Fore.YELLOW}{Spiel.punktmaximum_attribut}{Fore.RESET} liegen.\n")
    if hitos_pc.rasse == "Kängu" or hitos_pc.rasse == "Minotaurus" or hitos_pc.rasse == "Limakoid":
        print(f"Durch deine Rassen- oder Spezieswahl ist die Auswahl allerdings nicht einheitlich.\n")
        warte()
        print(f"Deine Stärke muss maximal {Fore.YELLOW}{Spiel.max_staerke}{Fore.RESET} betragen, "
              f"und deine Reflexe dürfen maximal {Fore.YELLOW}{Spiel.max_reflexe}{Fore.RESET} "
              f"Punkte haben.\n")
        warte()
    while True:
        try:
            frage_staerke = int(input("Gib den Stärke-Wert deines Charakters ein.\n > "))
            warte()
            frage_reflexe = int(input("Gib den Reflexe-wert deines Charakters ein.\n > "))
            warte()
            frage_wille = int(input("Gib den Wille-wert deines Charakters ein.\n > "))
            warte()
            frage_intellekt = int(input("Gib den Intellekt-wert deines Charakters ein.\n > "))
            warte()
        except (ValueError, TypeError):
            hoppla()
            attribute.clear()
            continue
        else:
            attribute.append(frage_staerke)             # Werte in die Tabelle zur Auszählung übertragen
            attribute.append(frage_reflexe)
            attribute.append(frage_wille)
            attribute.append(frage_intellekt)
            summe = sum(attribute)
            print(f"Du hast insgesamt {Fore.YELLOW}{summe}{Fore.RESET} Punkte verteilt.\n")
            if (any(attribute) > Spiel.punktmaximum_attribut
                    or attribute[0] > Spiel.max_staerke or attribute[1] > Spiel.max_reflexe):
                print("Du hast hast zu viele Punkte auf ein Attribut verteilt. Bitte wiederhole deine Verteilung.\n")
                attribute.clear()
                warte()
                continue
            if summe > Spiel.punkte["Attribute"]:
                print("Diese Summe übersteigt die verfügbaren Punkte. "
                      "Bitte wiederhole deine Verteilung.\n")
                attribute.clear()
                warte()
                continue
            if summe < Spiel.punkte["Attribute"]:
                print("Diese Summe ist zu wenig, es bleiben noch Punkte übrig. "
                      "Bitte Wiederhole deine Verteilung.\n")
                attribute.clear()
                warte()
                continue
            print("Damit sind die Attributpunkte verteilt. Weiter geht's!\n")
            hitos_pc.attribute["Stärke"] = attribute[0]     # Wenn die Rechnung aufgeht, werden die Werte auf den
            hitos_pc.attribute["Reflexe"] = attribute[1]    # Charakter übertragen.
            hitos_pc.attribute["Wille"] = attribute[2]
            hitos_pc.attribute["Intellekt"] = attribute[3]
            warte()
            return


def ausrichtung():
    archetyp = ["Kämpfer: Schläger", "Kämpfer: Schütze", "Dieb/Hacker",
                "Gelehrter/Forscher", "Okkultist", "Arkaner Zauberer/Psioniker"]
    dict_archetyp = {}
    print("Wähle einen Archetyp für deinen Charakter aus der folgenden Liste aus:\n")
    for index, element in enumerate(archetyp, 1):
        print(f"{index}: {element}\n")
        dict_archetyp[index] = element
    while True:
        try:
            frage = int(input("Gib nun die Nummer der Option ein, die deiner Vorstellung am ehesten entspricht, "
                              f"oder {Fore.YELLOW}0{Fore.RESET}, um eine Zufallsauswahl zu treffen.\n > "))
        except (ValueError, TypeError):
            hoppla()
            continue
        else:
            if frage in dict_archetyp.keys():
                Spiel.archetyp = dict_archetyp[frage]
                print(f"Alles klar! Dein Archetyp ist {Fore.YELLOW}{Spiel.archetyp}{Fore.RESET}.\n")
                warte()
                return
            elif frage == 0:
                Spiel.archetyp = random.choice(archetyp)
                print(f"Alles klar! Dein Archetyp ist {Fore.YELLOW}{Spiel.archetyp}{Fore.RESET}.\n")
                warte()
                return
            else:
                hoppla()


def konkretisierung_attribute():
    print("Im Hitos-System brauchen die Attribute eines Charakters eine sogenannte Konkretisierung.\n")
    warte()
    print("Der Wert der einzelnen Attribute gibt an, wie gut der Charakter in einem bestimmten Aspekt ist.\n")
    warte()
    print("Indem diese mit einer Konkretisierung erweitert werden, sticht eine Tätigkeit, die mit diesem Attribut "
          "zusammenhängt, besonders hervor.\n")
    warte()
    while True:
        frage = input(f"Gib {Fore.YELLOW}1{Fore.RESET} ein, wenn du diese Konkretisierungen selbst bestimmen willst, "
                      f"oder etwas Anderes, um sie automatisch bestimmen zu lassen.\n > ")
        if frage == "1":
            warte()
            kon1 = input(f"Gib deine Konkretisierung für das Attribut {Fore.YELLOW}Stärke{Fore.RESET} ein. \n > ")
            hitos_pc.konkretisierung_attribute["Stärke"] = kon1
            warte()
            kon2 = input(f"Gib deine Konkretisierung für das Attribut {Fore.YELLOW}Reflexe{Fore.RESET} ein. \n > ")
            hitos_pc.konkretisierung_attribute["Reflexe"] = kon2
            warte()
            kon3 = input(f"Gib deine Konkretisierung für das Attribut {Fore.YELLOW}Wille{Fore.RESET} ein. \n > ")
            hitos_pc.konkretisierung_attribute["Reflexe"] = kon3
            warte()
            kon4 = input(f"Gib deine Konkretisierung für das Attribut {Fore.YELLOW}Intellekt{Fore.RESET} ein. \n > ")
            hitos_pc.konkretisierung_attribute["Reflexe"] = kon4
            warte()
            print("Verstanden! Weiter geht's!\n")
            warte()
            return True
        else:
            return False


def fertigkeiten():
    print("Nun zu den Fertigkeiten.\n")
    warte()
    print("Das Hitos-System geht das davon, dass ein Charakter die meisten Tätigkeiten in dem einen oder anderen "
          "Maße beherrscht.\n")
    warte()
    print(f"Daher sind die Fertigkeiten eher in Kategorien eingeteilt: {Fore.YELLOW}Sportlichkeit, Kampf, Interaktion,"
          f" Heimlichkeit, Wahrnehmung, Bildung, Profession, Mythos und Magische Fertigkeit/Psionik.{Fore.RESET}\n")
    warte()
    print(f"Magie/Psionik ist dabei je nach Spiel und Charakter optional, daher darf sie den Wert "
          f"{Fore.YELLOW}0{Fore.RESET} haben.\n")
    warte()
    print(f"Die anderen Kategorien müssen einen Wert zwischen {Fore.YELLOW}1{Fore.RESET} "
          f"und {Fore.YELLOW}{Spiel.punktmaximum_fertigkeit}{Fore.RESET} haben.\n")
    warte()
    print(f"Insgesamt hast du {Fore.YELLOW}{Spiel.punkte["Fertigkeiten"]}{Fore.RESET} Punkte zu verteilen.\n")
    warte()
    print("Dabei darf ein Charakter grundsätzlich mehrere Fertigkeiten der gleichen Kategorie haben, "
          "der Einfachheit halber bleiben wir hier aber bei einer Fertigkeit pro Kategorie.\n")
    warte()
    fertigkeiten = []
    punkte = Spiel.punkte["Fertigkeiten"]
    while True:
        try:    # Eingabeaufforderung, einen Wert für jede Fertigkeitskategorie einzugeben.
            for element in hitos_pc.fertigkeiten.keys():
                eingabe = int(input(f"Gib den {element}-Wert deines Charakters ein.\n > "))
                warte()
                punkte -= eingabe
                print(f"Du hast {Fore.YELLOW}{eingabe}{Fore.RESET} Punkte auf die Fertigkeit "
                      f"{Fore.YELLOW}{element}{Fore.RESET} verteilt. Es bleiben noch {Fore.YELLOW}{punkte}{Fore.RESET} "
                      f"zu verteilen.\n")
                warte()
                fertigkeiten.append(eingabe)
        except (ValueError, TypeError):
            hoppla()
            fertigkeiten.clear()
            punkte = Spiel.punkte["Fertigkeiten"]
            continue
        else:
            summe = sum(fertigkeiten)
            print(f"Du hast insgesamt {Fore.YELLOW}{summe}{Fore.RESET} Punkte verteilt.\n")
            if summe > Spiel.punkte["Fertigkeiten"]:
                print("Diese Summe übersteigt die verfügbaren Punkte. Bitte wiederhole deine Verteilung.\n")
                fertigkeiten.clear()
                punkte = Spiel.punkte["Fertigkeiten"]
                warte()
                continue
            # Neustart, wenn der Benutzer zu viele oder zu wenige Punkte verteilt hat.
            elif any(fertigkeiten) > Spiel.punktmaximum_fertigkeit or any(fertigkeiten) < 0 and fertigkeiten[-1] == 0:
                print("Du hast zu viele eine oder mehrere Fertigkeit(en) zu hoch gesetzt oder "
                      "(ausgenommen Magie/Psionik) auf 0 gelassen.\n")
                warte()
                print("Bitte wiederhole deine Verteilung.\n")
                fertigkeiten.clear()
                punkte = Spiel.punkte["Fertigkeiten"]
                warte()
            elif summe < Spiel.punkte["Fertigkeiten"]:
                print("Diese Summe ist zu wenig, es bleiben noch Punkte übrig. "
                      "Bitte Wiederhole deine Verteilung.\n")
                fertigkeiten.clear()
                punkte = Spiel.punktmaximum_fertigkeit
                warte()
                continue
            else:   # Wenn die Rechnung aufgeht, werden die Werte der Fertigkeiten in ihrer Reihenfolge verteilt.
                for key, element in zip(hitos_pc.fertigkeiten.keys(), fertigkeiten):
                    hitos_pc.fertigkeiten[key] = element
                print("Deine Verteilung sieht also folgendermaßen aus:\n")
                warte()
                for key, value in hitos_pc.fertigkeiten.items():    # Darstellung der Fertigkeiten
                    print(f"{key}: {value}\n")
                    wartekurz()
                warte()
                print("Damit sind die Fertigkeitspunkte verteilt. Weiter geht's!\n")
                warte()
                return


def konkretisierung_fertigkeiten():
    print("Auch Fertigkeiten sollen im Hitos-System eine Konkretisierung bekommen.\n")
    warte()
    print("Diese gibt im Groben an, woraus dein Charakter in der jeweiligen Kategorie spezialisiert ist bzw. "
          "besonders gut kann.\n")
    print(f"Für einen hohen Wert in der Kategorie {Fore.YELLOW}Sportlichkeit{Fore.RESET} wäre "
          f"etwa {Fore.YELLOW}Scharfschütze{Fore.RESET} eine gute Wahl, falls sich dein Charakter darauf "
          f"spezialisieren will.\n")
    warte()
    print(f"Oder {Fore.YELLOW}Parkour{Fore.RESET} für einen Charakter mit einem sportlichen Hintergrund.\n")
    warte()
    print("Das Wichtigste ist: Es soll für deinen Charakter Sinn ergeben und zu ihm passen.\n")
    warte()
    frage = input(f"Gib nun {Fore.YELLOW}1{Fore.RESET} ein, wenn du diese Konkretisierungen selbst erstellen willst, "
                  f"oder etwas Anderes, wenn du sie zufällig generiert haben willst.\n > ")
    if frage != "1":
        return False
    else:
        for element in hitos_pc.konkretisierung_fertigkeiten.keys():
            eingabe = input(f"Gib deine Konkretisierung für die Fertigkeitskategorie "
                            f"{Fore.YELLOW}{element}{Fore.RESET} ein.\n > ")
            hitos_pc.konkretisierung_fertigkeiten[element] = eingabe
        print("Verstanden! Deine Verteilung sieht also folgendermaßen aus:\n")
        warte()
        for key, value in hitos_pc.konkretisierung_fertigkeiten.items():
            print(f"{key}: {value}\n")
            wartekurz()
        warte()
        print("Und damit machen wir jetzt weiter.\n")
        return True


def attribute_generiert():
    punkte_attribute = Spiel.punkte["Attribute"] # Zu verteilende Punkte werden übergeben.
    prozentverteilung = []

    if "Schläger" in Spiel.archetyp:    # Zu verteilende Punkte werden entsprechend dem Archetyp prozentual aufgeteilt.
        prozentverteilung = [38, 25, 25, 12]
    elif "Schütze" in Spiel.archetyp:
        prozentverteilung = [25, 37, 19, 19]
    elif "Dieb" in Spiel.archetyp:
        prozentverteilung = [19, 31, 19, 31]
    elif "Forscher" in Spiel.archetyp:
        prozentverteilung = [12, 19, 31, 38]
    elif "Okkultist" in Spiel.archetyp:
        prozentverteilung = [19, 19, 31, 31]
    else:
        prozentverteilung = [12, 19, 40, 30]
    verteilung = [round(punkte_attribute * element / 100) for element in prozentverteilung]  # Erstverteilung der Punkte
    rundungdsausgleich = punkte_attribute - sum(verteilung)  # Rundungsfehler ausgleichen.
    for element in range(abs(rundungdsausgleich)):  # Anpassung der Verteilung nach Rundungsausgleich.
        index = element % len(verteilung)
        if rundungdsausgleich > 0:
            verteilung[index] += 1
        if rundungdsausgleich < 0:
            verteilung[index] -= 1
    # Die ausgerechneten Werte auf die Attribute verteilen.
    for key, value in zip(hitos_pc.attribute.keys(), verteilung):
        hitos_pc.attribute[key] = value
    return


def kontretisierung_attribute_generiert():
    liste_staerke_gering = ["„Ich bräuchte mal Hilfe... Das ist zu schwer“.",
                            "„Klar helfe ich! Aber... Kannst du das hier bitte tragen“?", "Haut und Knochen",
                            "Zierlicher Körperbau", "Sehr schlank"]
    liste_staerke_mittel = ["„Ich kriege das schon hin... Gib mir einen Moment“!",
                            "„Wenn du mir dabei hilfst, sind wir im Nu fertig“!", "Schlank, aber sportlich",
                            "Hobby-Jogger", "Normal gebaut", "Abo fürs Fitness-Studio"]
    liste_staerke_hoch = ["„Klar kriege ich das getragen“!", "„Geh zur Seite und lass mich machen“!", "Kräftig",
                          "Robust gebaut", "Athletischer Körperbau"]
    liste_reflexe_gering = ["„Upps! Das sollte eigentlich nicht runterfallen“.",
                            "„Vorsicht! Oh, ich wollte das wirklich nicht umwerfen“.", "Lahme Ente", "Tollpatsch",
                            "Elefant im Porzellanladen"]
    liste_reflexe_mittel = ["„Ich bin nicht superschnell, aber es reicht aus“.",
                            "„Ich denke, wir kriegen den Dreh langsam raus“!", "Geschickt", "Flink",
                            "Leichter Schritt"]
    liste_reflexe_hoch = ["„Ruhige Hand und blitzschnelle Reflexe? Klar, schau zu und lerne“!",
                          "„Warum bist du so langsam“?", "Entfesselungskünstler", "Athletisch gebaut", "Akrobat",
                          "Treffsicher"]
    liste_wille_gering = ["„Ich halte es nicht aus. Sollen Andere es doch tun“!",
                          "„Ich denke, das wird uns zu viel. Lass uns lieber umkehren“!", "Abergläubisch"]
    liste_wille_mittel = ["„Ich werde nicht lügen: Es ist hart. Aber so leicht gebe ich nicht auf“.",
                          "„Es ist hart, aber mit genug Nachdruck kriegen wir's hin“!",
                          "„Was auch immer passiert: Ich bleibe hier bis zum Ende“!", "Unberechenbar",
                          "Dickkopf", "Hartnäckig", "Charismatisch", "Fromm", "Unentschlossen", "Schüchtern"]
    liste_wille_hoch = ["„Die Entscheidung steht fest, versuch gar nicht, mich umzustimmen“!", "Fest entschlossen",
                        "Unbeugsamer Wille", "Geborener Anführer", "Zielstrebig"]
    liste_intellekt_gering = ["“Das ist mir zu hoch“!", "“Warte, warte! Noch einmal und bitte langsamer“.",
                              "unkonzentriert", "geistig abwesend", "Einfaltspinsel", "Einfallslos", "Verpeilt",
                              "Steht auf dem Schlauch"]
    liste_intellekt_mittel = ["„Ich bin mir nicht sicher, ob ich das verstehe.\"",
                              "„Ich glaube, das Wichtigste habe ich versanden.\"", "Ungeduldig", "Aufmerksam",
                              "Ganz bei der Sache", "Schlaufuchs"]
    liste_intellekt_hoch = ["„Das ist voll einfach, die Lösung liegt quasi auf der Hand!\"",
                            "„Eine Sache hast du leider nicht mitbedacht, und zwar...\"", "Schlaumeier", "Berechnend",
                            "Hochbegabt", "Hoher IQ", "Blitzmerker"]
    # Nachfolgend eine zufällig ausgewählte Konkretisierung für jedes Attribut.
    # Es gibt Konkretisierungspools für niedrige, mittlere und hohe Werte.
    if hitos_pc.attribute["Stärke"] in range(1, 4):
        hitos_pc.konkretisierung_attribute["Stärke"] = random.choice(liste_staerke_gering)
    elif hitos_pc.attribute["Stärke"] in range(4, 7):
        hitos_pc.konkretisierung_attribute["Stärke"] = random.choice(liste_staerke_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Stärke"] = random.choice(liste_staerke_hoch)

    if hitos_pc.attribute["Reflexe"] in range(1, 4):
        hitos_pc.konkretisierung_attribute["Reflexe"] = random.choice(liste_reflexe_gering)
    elif hitos_pc.attribute["Reflexe"] in range(4, 7):
        hitos_pc.konkretisierung_attribute["Reflexe"] = random.choice(liste_reflexe_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Reflexe"] = random.choice(liste_reflexe_hoch)

    if hitos_pc.attribute["Wille"] in range(1, 4):
        hitos_pc.konkretisierung_attribute["Wille"] = random.choice(liste_wille_gering)
    elif hitos_pc.attribute["Wille"] in range(4, 7):
        hitos_pc.konkretisierung_attribute["Wille"] = random.choice(liste_wille_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Wille"] = random.choice(liste_wille_hoch)

    if hitos_pc.attribute["Intellekt"] in range(1, 4):
        hitos_pc.konkretisierung_attribute["Intellekt"] = random.choice(liste_intellekt_gering)
    elif hitos_pc.attribute["Intellekt"] in range(4, 7):
        hitos_pc.konkretisierung_attribute["Intellekt"] = random.choice(liste_intellekt_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Intellekt"] = random.choice(liste_intellekt_hoch)
    return


def fertigkeiten_generiert():
    punkte_fertigkeiten = Spiel.punkte["Fertigkeiten"]  # Zu verteilende Punkte werden übergeben.
    prozentverteilung = []
    if "Schläger" in Spiel.archetyp:
        prozentverteilung = [14, 20, 9, 14, 14, 12, 12, 5, 0]
    elif "Schütze" in Spiel.archetyp:
        prozentverteilung = [11, 14, 14, 20, 11, 11, 14, 5, 0]
    elif "Dieb" in Spiel.archetyp:
        prozentverteilung = [11, 11, 20, 14, 14, 12, 12, 6, 0]
    elif "Forscher" in Spiel.archetyp:
        prozentverteilung = [6, 6, 10, 15, 6, 20, 20, 14, 3]
    elif "Okkultist" in Spiel.archetyp:
        prozentverteilung = [6, 9, 11, 11, 9, 11, 11, 21, 11]
    else:
        prozentverteilung = [5, 10, 10, 12, 5, 12, 12, 14, 20]
        if Spiel.genre["Horror"]:
            hitos_pc.degeneration += 1
    verteilung = [round(punkte_fertigkeiten * element / 100) for element in prozentverteilung] # Erstverteilung
    rundungdsausgleich = punkte_fertigkeiten - sum(verteilung)  # Rundungsfehler ausgleichen.
    for element in range(abs(rundungdsausgleich)):  # Anpassung der Verteilung nach Rundungsausgleich.
        index = element % len(verteilung)
        if rundungdsausgleich > 0:
            verteilung[index] += 1
        if rundungdsausgleich < 0:
            verteilung[index] -= 1
    # Die ausgerechneten Werte auf die Attribute verteilen.
    for key, value in zip(hitos_pc.fertigkeiten.keys(), verteilung):
        hitos_pc.fertigkeiten[key] = value
    return



def konkretisierung_fertigkeiten_generiert():
    liste_sportlichkeit_gering = ["Joggen", "Freischwimmen", "Klettern"]
    liste_sportlichkeit_mittel = ["Akrobat", "Parcour", "Marathonlauf"]
    liste_sportlichkeit_hoch = ["Ausdauer-Lauf", "Olympia-reifes Turnen", "Parcour-Meister"]
    liste_kampf_gering = ["Selbstverteidigung", "Kneipenschlägerei", "Schießstand-Übung"]
    liste_kampf_mittel = ["Revolverheld", "Geübt mit Klingen", "Ringen", "Gute Reflexe"]
    liste_kampf_hoch = ["Scharfschütze", "Kampfkünste", "Fechten"]
    liste_wahrnehmung_gering = ["Beobachtungsgabe", "Gutes Gehör", "Spürnase"]
    liste_wahrnehmung_mittel = ["Spurenlesen", "Lippenlesen", "Gut im Dunkeln sehen"]
    liste_wahrnehmung_hoch = ["Körpersprache erkennen", "Sechster Sinn", "Adleraugen"]
    liste_interaktion_gering = ["Verkaufstalent", "Smalltalk", "Unterhaltung am Laufen erhalten"]
    liste_interaktion_mittel = ["Verhandlungsgenie", "Einschüchtern", "Unterschwellige Drohung", "Geborener Redner"]
    liste_interaktion_hoch = ["Diplomat", "Meister-Manipulator", "Manipulation der Massen"]
    liste_heimlichkeit_gering = ["Leiser Schritt", "Verstecken", "Eigene Absichten verstecken"]
    liste_heimlichkeit_mittel = ["Beschatten", "Verkleiden", "Taschendiebstahl"]
    liste_heimlichkeit_hoch = ["In der Menge untertauchen", "Trickbetrug", ]
    liste_profession = ["Koch", "Söldner", "Techniker", "Geistlicher", "Soldat", "Händler", "Spion", "Fleischer",
                        "Sportler", "Bäcker", "Kaufmann/Kauffrau"]
    liste_bildung_gering = ["Allgemeinbildung", "Lebenserfahrung", "Autodidakt"]
    liste_bildung_mittel = ["Linguistik", "Wissenschaftliches Vorgehen", "Leseratte"]
    liste_bildung_hoch = ["Polyglot", "Studium", "Breites theoretisches Wissen"]
    liste_magie = ["Teleportation", "Gedankenmanipulation", "Wetterkontrolle", "Reizüberflutung", "Illusion erschaffen",
                   "Gedanken lesen", "Telekinese", "Pyrokinese", "Blitz", "Astralprojektion",
                   "Manipulation der Elemente", "Telepathie", "Traumreise", "Halluzinationen verursachen"]
    liste_mythos = ["Ritual vorbereiten", "Folklore", "Aberglaube", "Symboldeutung"]
    if hitos_pc.fertigkeiten["Magie/Psionik"] != 0:
        hitos_pc.konkretisierung_fertigkeiten["Magie/Psionik"] = random.choice(liste_magie)

    if hitos_pc.fertigkeiten["Sportlichkeit"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Sportlichkeit"] = random.choice(liste_sportlichkeit_gering)
    elif hitos_pc.fertigkeiten["Sportlichkeit"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Sportlichkeit"] = random.choice(liste_sportlichkeit_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Sportlichkeit"] = random.choice(liste_sportlichkeit_hoch)

    if hitos_pc.fertigkeiten["Kampf"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Kampf"] = random.choice(liste_kampf_gering)
    elif hitos_pc.fertigkeiten["Kampf"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Kampf"] = random.choice(liste_kampf_mittel)
    else:
        hitos_pc.konkretisierung_attribute["Kampf"] = random.choice(liste_kampf_hoch)

    if hitos_pc.fertigkeiten["Wahrnehmung"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Wahrnehmung"] = random.choice(liste_wahrnehmung_gering)
    elif hitos_pc.fertigkeiten["Wahrnehmung"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Wahrnehmung"] = random.choice(liste_wahrnehmung_mittel)
    else:
        hitos_pc.konkretisierung_fertigkeiten["Wahrnehmung"] = random.choice(liste_wahrnehmung_hoch)

    if hitos_pc.fertigkeiten["Interaktion"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Interaktion"] = random.choice(liste_interaktion_gering)
    elif hitos_pc.fertigkeiten["Interaktion"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Interaktion"] = random.choice(liste_interaktion_mittel)
    else:
        hitos_pc.konkretisierung_fertigkeiten["Interaktion"] = random.choice(liste_interaktion_hoch)

    if hitos_pc.fertigkeiten["Heimlichkeit"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Heimlichkeit"] = random.choice(liste_heimlichkeit_gering)
    elif hitos_pc.fertigkeiten["Heimlichkeit"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Heimlichkeit"] = random.choice(liste_heimlichkeit_mittel)
    else:
        hitos_pc.konkretisierung_fertigkeiten["Heimlichkeit"] = random.choice(liste_heimlichkeit_hoch)

    hitos_pc.konkretisierung_fertigkeiten["Profession"] = random.choice(liste_profession)

    if hitos_pc.fertigkeiten["Bildung"] in range(1, 4):
        hitos_pc.konkretisierung_fertigkeiten["Bildung"] = random.choice(liste_bildung_gering)
    elif hitos_pc.fertigkeiten["Bildung"] in range(4, 7):
        hitos_pc.konkretisierung_fertigkeiten["Bildung"] = random.choice(liste_bildung_mittel)
    else:
        hitos_pc.konkretisierung_fertigkeiten["Bildung"] = random.choice(liste_bildung_hoch)

    hitos_pc.konkretisierung_fertigkeiten["Mythos"] = random.choice(liste_mythos)
    return
