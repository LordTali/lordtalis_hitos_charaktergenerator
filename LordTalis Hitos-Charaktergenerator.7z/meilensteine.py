from steuerelemente import *
from charakter import *
import random
from colorama import Fore

"""
In dieser Datei werden die Meilensteine des Charakters bestimmt.
"""


def meilensteine():
    print("Nun zu den Meilensteinen - das namensgebende Element des Hitos-Systems.\n")
    warte()
    print("Dein Charakter braucht einige Schlüsselereignisse in seinem Leben. Der Einfachheit halber "
          "beschränken wir uns hier vier von ihnen.\n")
    warte()
    print("Willst deine Meilensteine selbst entwerfen, oder diese zufällig erstellen lassen?\n")
    warte()
    while True:
        frage = input(f"Gib {Fore.YELLOW}1{Fore.RESET} ein, wenn du die Meilensteine erstellen willst, "
                      f"oder etwas Anderes, um sie erstellen zu lassen. \n > ").lower()
        if frage == "1":
            warte()
            auswahl_1 = input("Gib nun den ersten Meilenstein deines Charakters ein: \n > ")
            warte()
            auswahl_2 = input("Gib nun den zweiten Meilenstein deines Charakters ein: \n > ")
            warte()
            auswahl_3 = input("Gib nun den dritten Meilenstein deines Charakters ein: \n > ")
            warte()
            auswahl_4 = input("Gib nun den vierten Meilenstein deines Charakters ein: \n > ")
            warte()
            hitos_pc.meilensteine.append(auswahl_1)
            hitos_pc.meilensteine.append(auswahl_2)
            hitos_pc.meilensteine.append(auswahl_3)
            hitos_pc.meilensteine.append(auswahl_4)
            return True
        else:
            return False


def meilensteine_generiert():
    liste_meilensteine = ["Hat eine geliebte Person auf tragische Weise verloren.",
                          "War früher in einer Bande/Gang."
                          "Hat früher Militärdienst geleistet.",
                          "Wuchs in Armut auf.",
                          "Hat eine sichtbare Narbe durch einen Unfall bekommen.",
                          "Wurde als Kind Zeuge eines Gewaltverbrechens.",
                          "Wurde von seiner/ihrer Familie verstoßen.",
                          "Hat früher auf der Straße gelebt.",
                          "Wurde als Kind misshandelt.",
                          "Wurde einmal Opfer einer Entführung und konnte fliehen.",
                          "Überlebte eine eine Geiselnahme.",
                          "Wurde als Kind vernachlässigt.",
                          "Hatte früher ein Suchtproblem.",
                          "Hat einen Bildungsweg abgebrochen.",
                          "Hat einen Krieg als Zivilist überlebt.",
                          "War unschuldig im Gefängnis.",
                          "Hat einmal eine Person in Notwehr getötet.",
                          "Hat einmal jemanden im Streit getötet.",
                          "War früher in einer Sekte."
                          "Hat einige Zeit im Gefängnis wegen eines begangenen Verbrechens verbracht.",
                          "Hat eine (Natur-)Katastrophe überlebt",
                          "War in seiner/ihrer Jugend Kleinverbrecher.",
                          "Hat jemandem einmal das Leben gerettet",
                          "Hat einmal eine nahestehende Person verraten.",
                          "Überlebte ein traumatisches Ereignis, eine nahestehende Person ist dabei jedoch gestorben.",
                          "Hat ein wirklich bedeutendes Ereignis miterlebt.",
                          "Hat einmal getötet, um ein Geheimnis zu bewahren.",
                          "Hat einmal etwas für sich Verwerfliches infolge einer Erpressung getan.",
                          "Führt eine geheime Ehe.",
                          "Wuchs als Waise oder Halbwaise auf.",
                          "War Teil einer revolutionären Bewegung.",
                          "Führte früher ein Geschäft, das letztlich scheiterte.",
                          "Hat eine gefährliche Reise mitgemacht und viel dabei gelernt.",
                          "Hat jemandem etwas als dessen letzten Wunsch versprochen, und wird davon geplagt.",
                          "Ist an einem kleinen Ort für eine Heldentat bekannt.",
                          "Schuldet einem Unterweltboss einen Gefallen.",
                          "Hatte einmal eine Nahtod-Erfahrung."]

    hitos_pc.meilensteine = random.sample(liste_meilensteine, 4)
    return
