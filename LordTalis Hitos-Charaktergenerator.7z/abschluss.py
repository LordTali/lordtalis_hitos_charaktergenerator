from steuerelemente import *
from charakter import *
from colorama import Fore
import random

"""
In dieser Datei wird das Ergebnis der Charaktererstellung ausgegeben.
"""
def ueberblick():
    print("Und das war's! Dein Character ist fertig!\n")
    warte()
    print("Trage das Ergebnis auf en offizielles Charakterblatt oder kopiere und drucke die nachfolgende "
          "Zusammenfassung aus, damit du deine Werte beim Spielen zur Hand hast.\n")
    warte()
    print("Hier ist das Ergebnis deiner Auswahl:\n")
    warte()
    print(f"{Fore.YELLOW}Name: {hitos_pc.name}\n")
    wartekurz()
    if Spiel.rassen:
        print(f"Rasse: {hitos_pc.rasse}\n")
        wartekurz()
    print(f"Konzept: {hitos_pc.konzept}\n")
    wartekurz()
    print(f"Zitat: {hitos_pc.zitat}\n")
    wartekurz()
    print()
    print("Meilensteine: \n")
    wartekurz()
    for element in hitos_pc.meilensteine:
        print(f"{element} \n")
        wartekurz()
    print()
    print(f"Schwäche: {hitos_pc.schwaeche}\n")
    wartekurz()
    print()
    print("Attribute: \n")
    wartekurz()
    for key, value in hitos_pc.attribute.items():
        wert = hitos_pc.konkretisierung_attribute.get(key, "")
        print(f"{key}: {value}  {Fore.GREEN}{wert}{Fore.YELLOW}\n")
        wartekurz()
    print()
    print("Fertigkeiten: \n")
    warte()
    for key, value in hitos_pc.fertigkeiten.items():
        wert = hitos_pc.konkretisierung_fertigkeiten.get(key, "")
        print(f"{key}: {value}  {Fore.GREEN}{wert}{Fore.YELLOW}\n")
        wartekurz()
    print()
    print("Sekundäre Werte: \n")
    wartekurz()
    for key, value in hitos_pc.sekundaere_werte.items():
        print(f"{key}: {value}\n")
        wartekurz()
    print()
    print(f"{Fore.RESET}Und das war's! Das Einzige, was jetzt noch fehlt, ist die Ausrüstung.\n")
    warte()
    print("Da diese im Hitos-System aber sehr subjektiv ist, solltest du darüber "
          "lieber mit deinem Spielleiter sprechen.\n")
    warte()
    warte()
    while True:
        frage = input("Willst du noch einen weiteren Charakter erstellen? Antworte bitte mit "
                      f"{Fore.YELLOW}ja{Fore.RESET} oder {Fore.YELLOW}nein{Fore.RESET}.\n > ").lower()
        if "ja" in frage:
            warte()
            Spiel.neuer_charakter = True
            return True
        elif "nein" in frage:
            print("Auf wiedersehen!\n")
            warte()
            quit()
        else:
            hoppla()
