from steuerelemente import *
from charakter import *
from colorama import Fore
import random

"""
In dieser Datei Wird das Zitat des Charakters bestimmt.
"""


def zitat():
    zitate = ["[Ich habe ein eigenes Zitat]", "Ich bin kein Held. Aber einer muss es tun, und wer, wenn nicht ich?",
              "Was verschlossen ist, kriege ich auf. Was versteckt ist, kann ich finden.",
              "Es ist keine saubere Angelegenheit. Aber einer muss sich nun mal die Hände schmutzig machen.",
              "Meine wahren Absichten wirst du nie erfahren. Und auch ich selbst nicht.",
              "Ich kann mich auf dieser Welt nur auf meinen Cheque verlassen. Und wehe dem, der mich übers Ohr haut.",
              "Da draußen gibt es Geheimnisse, für es die es sich lohnt, zu sterben.",
              "Ich habe meine Geheimnisse, und ich habe bereits getötet, um sie zu behalten.",
              "Niemand wird zurückgelassen!", "Wenn dein Puls nicht durch die Decke geht, dann machst du etwas falsch.",
              "Applaus brauche ich nicht. Es reicht, dass der Job erledigt ist.",
              "Jede Sache hat einen Haken. Du musst ihn nur finden, bevor man dich findet.",
              "Das Geheimnis ruft nach mir, und ich kann nicht widerstehen.",
              "Ich wurde geschlagen, aber nicht besiegt.", "Vor dem Gesetz kann sich verstecken, aber vor mir nicht.",
              "Den Sinn des Lebens verstehe ich nicht, die Suche danach schon.",
              "Halt' dich fest, gleich wird's holprig!", "Es ist nicht alles Gold, was glänzt.",
              "Nur weil es seltsam ist, muss es noch lange nicht magisch sein.", "Ich glaube nicht an Zufälle.",
              "Die Wahrheit wird im Streit geboren, und stirbt in jedem Krieg als Erste.",
              "Andere rechnen damit, dass ich scheitern werde. Meistens liegen sie damit falsch.",
              "Ich habe schon Schlimmeres erlebt. Wir kriegen das hin!",
              "Standards sind langweilig. Wir machen's unkonventionell!",
              "Alter hat nichts mit Wissen zu tun, Erfahrung schon.",
              "Ich werde mein Ziel erreichen, oder beim Versuch sterben!",
              "Geistern ist die Meinung der Anderen egal. Mir eigentlich auch."]
    dict = {}
    print("Jetzt kümmern wir uns um die Zitate.\n")
    warte()
    print("Zitate helfen dabei, den Charakter zu verstehen und richtig zu spielen.\n")
    warte()
    print("Im Grunde sind sie das Gleiche wie ein Konzept, aber minimal ausführlicher.\n")
    warte()
    print("Du kannst es dir am einfachsten als ein Lebensmotto vorstellen.\n")
    warte()
    print("Ausgehend vom Konzept deines Charakters: Welches Zitat würde am ehesten zu ihm passen?\n")
    warte()
    print(f"Gib die Nummer deiner Antwort ein. Alternativ: Gib {Fore.YELLOW}0{Fore.RESET} "
          "und dann ein eigenes Zitat ein.\n")
    warte()
    for index, element in enumerate(zitate):
        dict[index] = element
        print(f"{index}: \"{element}\"\n")
        wartekurz()
    while True:
        try:
            frage = int(input("Bitte gib die Nummer einer Option ein, die deinen Charakter am ehesten beschreibt, "
                              f"oder {Fore.YELLOW}-1{Fore.RESET}, um ein Zitat zufällig auszuwählen.\n > "))
        except (ValueError, TypeError):
            hoppla()
            continue
        else:
            warte()
            if frage == 0:
                warte()
                frage2 = input("Dann gib jetzt bitte dein Charakterzitat ein.\n > ")
                hitos_pc.zitat = frage2
                return
            elif frage == -1:
                hitos_pc.zitat = random.choice(zitate[1:])
                warte()
                print(f"Verstanden. Dein Charakterzitat ist: {Fore.YELLOW}{hitos_pc.zitat}{Fore.RESET}\n")
                warte()
                return
            elif frage in dict.keys() and frage != 0:
                hitos_pc.zitat = dict[frage]
                print(f"Verstanden. Dein Charakterzitat ist: {Fore.YELLOW}„{hitos_pc.zitat}“{Fore.RESET}\n")
                warte()
                return
            else:
                hoppla()
