Dieser Charaktergenerator soll Spielern im deutschsprachigen Raum dabei helfen, einen Charakter für das hierzulande (leider) wenig bekannte Hitos-System vom Vorlag Nosorol Ediciones zu erstellen, wie es zum Beispiel im Pen&Paper-Rollenspiel "Unaussprechliche Kulte" (In Deutschland vom Verlag Truant Spiele vertrieben) benutzt wird.

WICHTIG:

Der Autor dieses Generators erhebt keinerlei Anspruch auf das Hitos-System oder die einzelnen Regeln davon. Sämtliche Rechte am System gehören dem System-Autor, dem spanischen Verlag Norosorol Ediciones (Nosolorol S.L).
Lediglich der Code für den Generator und die Software selbst sind das Werk des Programmschöpfers.

ACHTUNG:

Bei der Ausführung der .exe-Datei kann eine Windows-Warnung erscheinen. Das liegt daran, dass die Software nicht über eine (kostenpflichtige) digitale Signatur verfügt. Sie kann aber mit einem Klick auf "Trotzdem ausführen" gefahrlos ausgeführt werden.