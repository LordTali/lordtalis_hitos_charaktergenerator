import time

"""
Diese Datei steuer die übergeordneten Variablen der Charaktererstellung.
"""

class Spiel:
    niveau = 0
    rassen = False
    genre = {"Horror": False, "Sci-Fi": False, "Fantasy": False}      # Hier wird das Genre bestimmt
    arkan = False       # Ob der Charakter zaubern kann
    psionik = False
    archetyp = None       # Ist der Charakter mehr auf Kampf, Interaktion, Schleichen oder Zaubern aus?
    punkte = {"Attribute": 0, "Fertigkeiten": 0}
    punktmaximum_attribut = 0
    punktmaximum_fertigkeit = 0
    max_staerke = 0
    max_reflexe = 0
    neuer_charakter = False


def warte():
    time.sleep(3)


def wartekurz():
    time.sleep(0.5)


def hoppla():
    print("Hoppla! Irgendwas ist bei der Eingabe schiefgegangen. Versuch's bitte noch einmal.\n")
    warte()
    return
