from steuerelemente import *
from charakter import *
from colorama import Fore
from faker import Faker
import random

"""
In dieser Datei werden der Name und das Konzept des Charakters bestimmt.
"""

def name():
    print("Eine Charaktererstellung beginnt in so ziemlich jedem Spiel mit dem Namen.\n")
    warte()
    print("Willst dir selbst einen Namen zulegen, oder diesen zufällig erstellen lassen?\n")
    warte()
    frage = input(f"Gib {Fore.YELLOW}1{Fore.RESET} ein, wenn du selbst einen Namen eintragen willst, "
                  "oder etwas Anderes, um den Namen zufällig erstellen zu lassen.\n > ")
    warte()
    if frage == "1":
        auswahl = input("Gib nun den Namen deines Charakters ein:\n > ")
        hitos_pc.name = auswahl
        warte()
        print(f"Verstanden! Der Name deines Charakters ist {Fore.YELLOW}{hitos_pc.name}{Fore.RESET}.\n")
        warte()
        return True
    else:
        warte()
        return False


def name_generiert():
    klein = ""
    gross = ""
    print("Alles klar, dann erstellen wir jetzt einen zufälligen Namen.\n")
    warte()
    while True:
        try:
            auswahl = input("Gib das Kürzel aus zwei Zeichen für die Sprache ein, "
                            "nach der der Name klingen soll:\n > ").lower()
            klein = auswahl
            gross = klein.upper()
            if klein == "en":
                gross = "US"
            if klein == "ja" or klein == "jp":
                klein = "ja"
                gross = "JP"
            if klein == "af":
                gross = "ZA"
            namensart = Faker(f"{klein}_{gross}")
            vor_und_nachname = namensart.name()
            warte()
        except:
            print("Hoppla! Wie es scheint, ist diese Option derzeit nicht vorgesehen. Der Zufallsgenerator "
                  "sucht daher etwas aus der Standard-Auswahl aus. \n")
            warte()
            namensart = Faker()
            vor_und_nachname = namensart.name()
        finally:
            print(f"Der Name deines Charakters ist {Fore.YELLOW}{vor_und_nachname}{Fore.RESET}.\n")
            hitos_pc.name = vor_und_nachname
            return


def konzept():
    konzepte = ["[Ich habe ein eigenes Konzept]", "Held wider Willen", "Begeisterter Hacker", "Technik-Freak",
                "Abgebrühter Cop", "Zweigesichtige Femme Fatale", "Skrupelloser Söldner", "Fanatiker des Okkulten",
                "Pflichtbewusster Feldmediziner", "Desillusionierter Gelehrter", "Adrenalin-Junkie",
                "Wortkarger Beschützer", "Straßenschlauer Überlebenskünstler", "Jäger des Verbotenen Wissens",
                "Verfechter der Selbstjustiz", "Frommer Prediger", "Ehrenhafter Duellkämpfer", "Stoischer Veteran",
                "Idealistischer Revoluzzer", "Autistisches Wunderkind", "(Ehemaliger) Sportler",
                "Erfahrener Drogendealer", "Militanter Veganer", "Tierlieber Soziopath", "Gescheiterter Buchautor",
                "Geisteskranker Arzt", "Enttäuschter Studienabbrecher", "Entscheidungsscheuer Dauerstudent",
                "Drogenabhängiger Workaholic", "Sensationsgeiler Journalist"]
    dict_konzept = {}
    print("Zusätzlich zum Namen gehört auch ein Konzept zum Kernelement der Charaktererstellung im Hitos-System.\n")
    warte()
    print("Konzepte fasst das gesamte Wesen eines Charakters in ein-zwei Worten zusammen.\n")
    warte()
    print("Daraus lässt das Wertesystem eines Charakters ableiten, damit du eine ungefähre Ahnung hast, wie du ihn "
          "spielen sollst.\n")
    warte()
    print("Wenn du an kein eigenes Konzept denken kannst, wähle eines der nachfolgenden (oder stell dir etwas "
          "aus den Optionen zusammen bzw. lass dich von den Optionen inspirieren "
          f"und gib {Fore.YELLOW}0{Fore.RESET} ein):\n")
    for index, element in enumerate(konzepte):
        dict_konzept[index] = element
        print(f"{index}: {element}\n")
        wartekurz()
    while True:
        try:
            frage = int(input(f"Bitte gib die Nummer einer Option ein, die dir für den Charakter "
                              f"am ehesten zusagt, oder {Fore.YELLOW}-1{Fore.RESET}, "
                              "um ein Konzept zufällig auszuwählen.\n > "))
        except (ValueError, TypeError):
            hoppla()
            continue
        else:
            if frage == 0:
                warte()
                frage2 = input("Alles klar! Dann gib jetzt bitte dein Charakterkonzept ein.\n > ").lower()
                hitos_pc.konzept = frage2
            elif frage == -1:
                hitos_pc.konzept = random.choice(konzepte[1:])
            elif frage in dict_konzept.keys() and frage != 0:
                hitos_pc.konzept = dict_konzept[frage]
            else:
                hoppla()
        finally:
            warte()
            print(f"Verstanden. Dein Charakterkonzept ist: {Fore.YELLOW}{hitos_pc.konzept}{Fore.RESET}.\n")
            warte()
            return
