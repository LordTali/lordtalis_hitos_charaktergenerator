from steuerelemente import *
from charakter import hitos_pc
from start_genre_rasse import *
from macht_und_punkte import *
from name_konzept import *
from zitat import *
from attribute_und_fertigkeiten import *
from meilensteine import *
from schwaeche import *
from sekundaere_werte import *
from abschluss import *
import colorama
from colorama import Fore

colorama.init()   # Colorama initialisieren

"""
Diese Datei steuert den Programmablauf.
"""

"""
Der Code des vorliegenden Programms ist under der MIT-Lizenz freigegeben, 
die Mechaniken und Namen als Bestandteile des Hitos-Systems stammen aber vom Verlag Nosolorol Ediciones.
Der Autor dieses Generators ist in keiner Weise mit Nosolorol assoziiert und erhebt keinerlei Anspruch gegenüber
dem System oder dessen Bestandteilen.
"""

def main():
    while True:
        if not Spiel.neuer_charakter:
            willkommen()
            warte()
        genre()
        warte()
        auswahl = rasse()
        warte()
        if auswahl:
            wahl_rasse()
            warte()
        macht()
        frage = name()
        if not frage:
            name_generiert()
        warte()
        konzept()
        warte()
        zitat()
        warte()
        frage = attribute()
        warte()
        if frage == "1":
            attribute_bestimmen()
            warte()
            frage = konkretisierung_attribute()
            warte()
            if not frage:
                kontretisierung_attribute_generiert()
            warte()
            fertigkeiten()
            warte()
            frage = konkretisierung_fertigkeiten()
            if not frage:
                if Spiel.archetyp == None:
                    ausrichtung()
                    warte()
                konkretisierung_fertigkeiten_generiert()
        else:
            ausrichtung()
            attribute_generiert()
            kontretisierung_attribute_generiert()
            fertigkeiten_generiert()
            konkretisierung_fertigkeiten_generiert()
        auswahl = meilensteine()
        if not auswahl:
            meilensteine_generiert()
        frage = schwaeche()
        if not frage:
            schwaeche_generiert()
        sekundaere_werte()
        frage = ueberblick()
        if frage:
            continue
        pass

if __name__ == "__main__":
    main()
