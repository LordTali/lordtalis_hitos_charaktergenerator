"""
Diese Datei enthält die Werte des zu erstellenden Charakters.
"""


class Charakter:
    def __init__(self, rasse, name, konzept, zitat, attribute, konkretisierung_attribute, fertigkeiten,
                 konkretisierung_fertigkeiten, sekundaere_werte, meilensteine,
                 ausruestung, degeneration, drama, schwaeche):
        self.rasse = rasse
        self.name = name
        self.konzept = konzept
        self.zitat = zitat
        self.attribute = attribute
        self.konkretisierung_attribute = konkretisierung_attribute
        self.fertigkeiten = fertigkeiten
        self.konkretisierung_fertigkeiten = konkretisierung_fertigkeiten
        self.sekundaere_werte = sekundaere_werte
        self.meilensteine = meilensteine
        self.ausruestung = ausruestung
        self.degeneration = degeneration
        self.drama = drama
        self.schwaeche = schwaeche


hitos_pc = Charakter("","", "", {"Stärke": 0, "Reflexe": 0, "Wille": 0, "Intellekt": 0},
                     {"Stärke": "", "Reflexe": "", "Wille": "", "Intellekt": ""},
                     {"Sportlichkeit": 0, "Kampf": 0, "Interaktion": 0, "Wahrnehmung": 0, "Heimlichkeit": 0,
                      "Bildung": 0, "Profession": 0, "Mythos": 0, "Arkanes/Psionik": 0},
                     {"Sportlichkeit": "", "Kampf": "", "Interaktion": "", "Wahrnehmung": "",
                      "Heimlichkeit": "", "Bildung": "", "Profession": "", "Mythos": "", "Magie/Psionik": ""},
                     {}, {}, [], 0, 5, "",
                     "")
