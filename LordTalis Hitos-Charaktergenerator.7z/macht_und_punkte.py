from steuerelemente import *
from charakter import *


def macht():
    machtniveau = ["Eigenes Machtniveau", "Gewöhnliche (Nicht-)Menschen", "Protagonisten", "Helden", "Titanen"]
    dict = {}
    print("Was ist das Machtniveau eurer Gruppe?\n")
    warte()
    for index, element in enumerate(machtniveau):
        dict[index] = element
        print(f"{index}: {element}\n")
        wartekurz()
    while True:
        try:
            frage = int(input("Gib jetzt die Zahl ein, die dem Machtniveau des Abenteuers entspricht.\n > "))
            warte()
        except (ValueError, TypeError):
            hoppla()
            warte()
            continue
        else:       # Der Spieler soll den Namen der Rasse und die zu verteilenden Punkte selbst eintragen.
            if hitos_pc.rasse == "Eigenbräu":
                frage = input("Gib nun den Namen der Rasse oder Spezies deines Charakters ein.\n > ")
                hitos_pc.rasse = frage
            if frage == 0:
                while True:
                    try:
                        auswahl1 = int(input("Gib nun die anzahl der zu verteilenden Attributpunkte "
                                             "deines Charakters ein.\n > "))
                        warte()
                        auswahl2 = int(input("Gib nun die anzahl der zu verteilenden Fertigkeitspunkte "
                                             "deines Charakters ein.\n > "))
                        warte()
                        auswahl3 = int(input("Gib nun die maximale Anzahl der Punkte "
                                             "je Attribut ein.\n > "))
                        auswahl4 = int(input("Gib nun die maximale Anzahl der Punkte "
                                             "je Fertigkeit ein.\n > "))
                        warte()
                    except (ValueError, TypeError):
                        hoppla()
                        warte()
                        continue
                    else:
                        print("Verstanden! Weiter geht's!\n")
                        warte()
                        Spiel.punkte["Attribute"] = auswahl1
                        Spiel.punkte["Fertigkeiten"] = auswahl2
                        Spiel.punktmaximum_attribut = auswahl3
                        Spiel.punktmaximum_fertigkeit = auswahl4
                        return
            elif frage == 1:    # Die Wahl der Rasse und das Machtniveau resultieren in Punktunterchieden.
                Spiel.niveau = 1
                if hitos_pc.rasse == "Mensch":  # Hier ist der Block für gewöhnliche Leute.
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    return
                elif hitos_pc.rasse == "Elf":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 6
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    return
                elif hitos_pc.rasse == "Zwerg":
                    Spiel.punkte["Attribute"] = 17
                    Spiel.punkte["Fertigkeiten"] = 37
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 4
                    return
                elif hitos_pc.rasse == "Halbelf":
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    return
                elif hitos_pc.rasse == "Halbling":
                    Spiel.punkte["Attribute"] = 14
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 6
                    return
                elif hitos_pc.rasse == "Ork":
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 5
                    return
                elif hitos_pc.rasse == "Minotaurus":
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 5
                    Spiel.max_staerke = 9
                    Spiel.max_reflexe = 6
                    return
                elif hitos_pc.rasse == "Kängu":
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 35
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 6
                    Spiel.max_staerke = 4
                    Spiel.max_reflexe = 8
                    return
                else:
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 37
                    Spiel.punktmaximum_attribut = 7
                    Spiel.punktmaximum_fertigkeit = 7
                    hitos_pc.drama = 5
                    Spiel.max_staerke = 10
                    Spiel.max_reflexe = 3
                    return
            elif frage == 2:                        # Hier ist der Block für Protagonisten.
                Spiel.niveau = 2
                if hitos_pc.rasse == "Mensch":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    return
                elif hitos_pc.rasse == "Elf":
                    Spiel.punkte["Attribute"] = 20
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum = 6
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Zwerg":
                    Spiel.punkte["Attribute"] = 19
                    Spiel.punkte["Fertigkeiten"] = 42
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Halbelf":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    return
                elif hitos_pc.rasse == "Halbling":
                    Spiel.punkte["Attribute"] = 16
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 5
                    return
                elif hitos_pc.rasse == "Ork":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    return
                elif hitos_pc.rasse == "Minotaurus":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    Spiel.max_staerke = 11
                    Spiel.max_reflexe = 8
                    return
                elif hitos_pc.rasse == "Kängu":
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 5
                    Spiel.max_staerke = 6
                    Spiel.max_reflexe = 10
                    return
                else:
                    Spiel.punkte["Attribute"] = 18
                    Spiel.punkte["Fertigkeiten"] = 42
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 9
                    hitos_pc.drama = 4
                    Spiel.max_staerke = 12
                    Spiel.max_reflexe = 5
                    return
            elif frage == 3:                        # Hier ist der Block für Helden.
                Spiel.niveau = 3
                if hitos_pc.rasse == "Mensch":
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Elf":
                    Spiel.punkte["Attribute"] = 26
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 9
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    return
                elif hitos_pc.rasse == "Zwerg":
                    Spiel.punkte["Attribute"] = 25
                    Spiel.punkte["Fertigkeiten"] = 42
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 2
                    return
                elif hitos_pc.rasse == "halbelf":
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Halbling":
                    Spiel.punkte["Attribute"] = 22
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 5
                    return
                elif hitos_pc.rasse == "Ork":
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Minotaurus":
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 3
                    Spiel.max_staerke = 12
                    Spiel.max_reflexe = 9
                    return
                elif hitos_pc.rasse == "Kängu":
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 40
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 4
                    Spiel.max_staerke = 7
                    Spiel.max_reflexe = 11
                    return
                else:
                    Spiel.punkte["Attribute"] = 24
                    Spiel.punkte["Fertigkeiten"] = 42
                    Spiel.punktmaximum_attribut = 10
                    Spiel.punktmaximum_fertigkeit = 10
                    hitos_pc.drama = 3
                    Spiel.max_staerke = 13
                    Spiel.max_reflexe = 6
                    return
            elif frage == 4:                                # Hier ist der Block für Titanen.
                Spiel.niveau = 4
                if hitos_pc.rasse == "Mensch":
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    return
                elif hitos_pc.rasse == "Elf":
                    Spiel.punkte["Attribute"] = 32
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 11
                    Spiel.punktmaximum_fertigkeit = 14
                    hitos_pc.drama = 1
                    return
                elif hitos_pc.rasse == "Zwerg":
                    Spiel.punkte["Attribute"] = 31
                    Spiel.punkte["Fertigkeiten"] = 52
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 1
                    return
                elif hitos_pc.rasse == "Halbelf":
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    return
                elif hitos_pc.rasse == "Halbling":
                    Spiel.punkte["Attribute"] = 28
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 3
                    return
                elif hitos_pc.rasse == "Ork":
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    return
                elif hitos_pc.rasse == "Minotaurus":
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    Spiel.max_staerke = 14
                    Spiel.max_reflexe = 11
                    return
                elif hitos_pc.rasse == "Kängu":
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 50
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 3
                    Spiel.max_staerke = 9
                    Spiel.max_reflexe = 13
                    return
                else:
                    Spiel.punkte["Attribute"] = 30
                    Spiel.punkte["Fertigkeiten"] = 52
                    Spiel.punktmaximum_attribut = 12
                    Spiel.punktmaximum_fertigkeit = 12
                    hitos_pc.drama = 2
                    Spiel.max_staerke = 15
                    Spiel.max_reflexe = 8
                    return
            else:
                hoppla()
