from steuerelemente import *
from charakter import *
from colorama import Fore

"""
In dieser Datei werden die sekundären Werte aufgrund von vorigen Eingaben ausgerechnet.
"""

def sekundaere_werte():
    print("Nun erstellen wir aufgrund deiner Attribute und Fertigkeiten noch andere Werte, die sich daraus ergeben.\n")
    warte()
    print("Die Formel dafür ist wie folgt:\n")
    warte()
    print("Konstitution: Stärke + (Wille/2)\n")
    hitos_pc.sekundaere_werte["Konstitution"] = hitos_pc.attribute["Stärke"] + (hitos_pc.attribute["Wille"] // 2)
    wartekurz()
    print("Gesundheit: Konstitution x 3\n")
    hitos_pc.sekundaere_werte["Gesundheit"] = hitos_pc.sekundaere_werte["Konstitution"] * 3
    wartekurz()
    if hitos_pc.fertigkeiten["Sportlichkeit"] > hitos_pc.fertigkeiten["Kampf"]:
        hitos_pc.sekundaere_werte["Verteidigung"] = (
                hitos_pc.attribute["Reflexe"] + hitos_pc.fertigkeiten["Sportlichkeit"] + 5)
    else:
        hitos_pc.sekundaere_werte["Verteidigung"] = (
                hitos_pc.attribute["Reflexe"] + hitos_pc.fertigkeiten["Kampf"] + 5)
    wartekurz()
    print("Initiative: Reflexe + (Intellekt / 2) \n ")
    hitos_pc.sekundaere_werte["Initiative"] = hitos_pc.attribute["Reflexe"] + hitos_pc.attribute["Intellekt"] // 2
    print("Schadensbonus (Fernkampf): Kampf / 4 \n")
    hitos_pc.sekundaere_werte["Schadensbonus (Fernkampf)"] = hitos_pc.fertigkeiten["Kampf"] // 4
    wartekurz()
    print("Schadensbonus (Nahkampf): (Kampf + Stärke) / 4\n")
    hitos_pc.sekundaere_werte["Schadensbonus (Nahkampf)"] = (
            (hitos_pc.attribute["Stärke"] + hitos_pc.fertigkeiten["Kampf"]) // 4)
    warte()
    while True:
        print("Spielt deine Gruppe mit den Regen der geistigen Gesundheit?\n")
        warte()
        frage = input(f"Gib {Fore.YELLOW}1{Fore.RESET} Ja oder Vielleicht ein, "
                      f"oder etwas Anderes für Nein.\n > ").lower()
        if frage == "1":
            warte()
            print("Entschlossenheit: Wille + (Intellekt / 2) \n")
            hitos_pc.sekundaere_werte["Entschlossenheit"] = (
                    hitos_pc.attribute["Wille"] + (hitos_pc.attribute["Intellekt"] // 2))
            wartekurz()
            print("Stabilität: Entschlossenheit x 3\n")
            hitos_pc.sekundaere_werte["Stabilität"] = hitos_pc.sekundaere_werte["Entschlossenheit"] * 3
            return
        else:
            warte()
            return
